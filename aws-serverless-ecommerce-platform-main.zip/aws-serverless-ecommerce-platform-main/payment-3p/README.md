# 3rd party payment service

This service simulates a third party backend system.

## API

See [resources/openapi.yaml](resources/openapi.yaml) for a list of available API paths.

## Events

_This service does not emit any event._

## SSM Parameters

This service defines the following SSM parameters:

* `/ecommerce/{Environment}/payment-3p/api/url`: URL for the API Gateway