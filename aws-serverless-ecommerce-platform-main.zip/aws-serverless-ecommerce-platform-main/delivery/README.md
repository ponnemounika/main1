# Delivery service

<p align="center">
  <img src="images/delivery.png" alt="Delivery service architecture diagram"/>
</p>

## API

_None at the moment._

## Events

_None at the moment._

## SSM Parameters

_None at the moment._